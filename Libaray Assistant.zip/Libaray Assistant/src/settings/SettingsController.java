package settings;

import javafx.fxml.FXML;

import javafx.fxml.Initializable;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;





public class SettingsController implements Initializable {
	
	@FXML
	private TextField nDaysWithoutFine;
	@FXML
	private TextField username;
	@FXML
	private TextField Fineperday;
	@FXML
	private PasswordField password;
	@FXML
	private AnchorPane rootpane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		initDefaultValues();
		
	}
	private void initDefaultValues() {
		Preferences preferences = Preferences.getpreferences();
		nDaysWithoutFine.setText(String.valueOf(preferences.getnDaysWithoutFine()));//getting the default values
		Fineperday.setText(String.valueOf(preferences.getFineperday()));
		username.setText(String.valueOf(preferences.getUsername()));
		password.setText(String.valueOf(preferences.getPassword()));
		
	}
	// Event Listener on Button.onAction which will save an update values
 	@FXML
	public void save(ActionEvent event) {
		int ndays = Integer.parseInt(nDaysWithoutFine.getText());
		float fine = Float.parseFloat(Fineperday.getText());
		String un = username.getText();
		String ps = password.getText();
		
 		Preferences prefrences = Preferences.getpreferences();
 		
 		prefrences.setnDaysWithoutFine(ndays);
 		prefrences.setFineperday(fine);
 		prefrences.setUsername(un);
 		prefrences.setPassword(ps);
 		
 		Preferences.writePrefencesToFile(prefrences);//old data will be deleted and new will be added
	}
	// Event Listener on Button.onAction
	@FXML
	public void cancel(ActionEvent event) {
		Stage stage =(Stage) rootpane.getScene().getWindow();
		stage.close();
	}
	
}
