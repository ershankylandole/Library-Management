package settings;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import alert.AlertMaker;

public class Preferences {
	public static final String CONFIG_FILE = "config.txt";
	
	int nDaysWithoutFine;
	float Fineperday;
	String username;
	String password;
	
	public Preferences() {
		
		nDaysWithoutFine =10;
		Fineperday = 2;
		username = "admin";
		password = "admin";
	}
	public int getnDaysWithoutFine() {
		return nDaysWithoutFine;
	}
	public void setnDaysWithoutFine(int nDaysWithoutFine) {
		this.nDaysWithoutFine = nDaysWithoutFine;
	}
	public float getFineperday() {
		return Fineperday;
	}
	public void setFineperday(float fineperday) {
		Fineperday = fineperday;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	//when we run the code for the first time and it will call the this method and create config.txt file. with the default values
	public static void initConfig() {
		Writer writer= null;
		Preferences preference = new Preferences();
		 Gson gson = new Gson();
		 try {
			writer = new FileWriter(CONFIG_FILE);
			gson.toJson(preference,writer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				writer.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
	
	//we want to read the current info from congif file  and returns the preference object
	public static Preferences getpreferences() {
		Gson gson = new Gson();
		Preferences preference = new Preferences();	
		try {
			preference = gson.fromJson(new FileReader(CONFIG_FILE), Preferences.class);//if there is no values in the file we are using default values
		} 
		 catch (FileNotFoundException e) {
			initConfig();//thi will create config file if file is not there
			e.printStackTrace();
		}
		return preference;// and return to the caller.
	}
	
	public static void writePrefencesToFile(Preferences preference)//passing parameter to get config info
	{
		Writer writer= null;
		 
		
		 try {
			 Gson gson = new Gson();
			writer = new FileWriter(CONFIG_FILE);
			gson.toJson(preference,writer);
			AlertMaker.showSimpleAlert("Sucess", "Settings Updated");
		} catch (IOException e) {
			AlertMaker.showErrorMessage("Failed","Settings could not be updated");
			
		}finally {
			try {
				writer.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
}
