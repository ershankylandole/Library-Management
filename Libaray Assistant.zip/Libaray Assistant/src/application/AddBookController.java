package application;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import alert.AlertMaker;
import database.DatabaseHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import listbook.ListBookController;

public class AddBookController implements Initializable {
	@FXML
	private TextField title;
	@FXML
	private TextField id;
	@FXML
	private TextField author;
	@FXML
	private TextField publisher;
	@FXML
	private Button savebutton;
	@FXML
	private Button cancelbutton;
	@FXML
	private AnchorPane rootpane;
	private Boolean isEditMode = Boolean.FALSE;//bcz it should only be editable when user select edit option
	
	
	DatabaseHandler databasehandler;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		databasehandler = databasehandler.getInstance();
		
		ChechData();
	}
	
	
	@FXML
	public void addbok(ActionEvent event)
	{
		String bookid = id.getText();
		String bookauthor = author.getText();
		String booktitle = title.getText();
		String bookpublisher = publisher.getText();
		
		//if empty return false else execute query
		if(bookid.isEmpty() || bookauthor.isEmpty() || booktitle.isEmpty() || bookpublisher.isEmpty()) {
			Alert al = new Alert(Alert.AlertType.ERROR);
			al.setHeaderText(null);
			al.setContentText("Plese enter in all Fields");
			al.showAndWait();
			return;
		}
		
		if(isEditMode) {
			handleEditOperation();
			return;
		}
		
		String qu = "insert into BOOK values("+
		"'" + bookid +"',"+
		"'" + booktitle +"',"+
		"'" + bookauthor +"',"+
		"'" + bookpublisher +"',"+
		"" + true +""+
		")";
		System.out.println(qu);
		//checking wether the action is complete or not and display in another box
		if(databasehandler.execAction(qu))
		{
			Alert al = new Alert(Alert.AlertType.INFORMATION);
			al.setHeaderText(null);
			al.setContentText("Successfully inserted");
			al.showAndWait();
		}
		else
		{

			Alert al = new Alert(Alert.AlertType.ERROR);
			al.setHeaderText(null);
			al.setContentText("Error!!! Please try Again");
			al.showAndWait();
		}
	}
	
	private void handleEditOperation() {
		
		ListBookController.Book book = new ListBookController.Book(title.getText(),id.getText(),author.getText(), publisher.getText(), true);
		
		if(databasehandler.updateBook(book)) {
			AlertMaker.showSimpleAlert("Success", "Book Updated");
			
		}else {
			AlertMaker.showErrorMessage("Failed","Cant update book");
		}
	}


	@FXML
	public void cancel(ActionEvent event)
	{
		
		Stage stage = (Stage) rootpane.getScene().getWindow();
		stage.close();
	}
	
	private void ChechData() {
		String qu = "select * from BOOK";
		ResultSet rs = databasehandler.execQuery(qu);
		
		try {
			while(rs.next())
			{
				String title = rs.getString("title");
				System.out.println(title);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(AddBookController.class.getName()).log(Level.SEVERE,null, e);
		}
		
	}
	
	public void inFlateUI(ListBookController.Book book) {
		
		title.setText(book.getTitle());
		id.setText(book.getId());
		author.setText(book.getAuthor());
		publisher.setText(book.getPublisher());
		id.setEditable(false);//id should not editable. if it is then nothing will work and will create problems on every situation  
		isEditMode = Boolean.TRUE;
	}



}
