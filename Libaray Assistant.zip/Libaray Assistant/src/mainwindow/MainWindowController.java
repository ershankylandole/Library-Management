package mainwindow;

import javafx.fxml.FXML;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import util.LibraryAssistantUtil;

import java.io.IOException;
import java.net.URL;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.ResourceBundle;

import database.DatabaseHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

public class MainWindowController implements Initializable {

	@FXML
	private HBox book_info;
	@FXML
	private StackPane rootpane;
	@FXML
	private HBox member_info;
	@FXML
	private ListView issueDataList;
	@FXML
	private TextField bookidinput;
	@FXML
	private Text bookname;
	
	@FXML
	private Text bookauthor;
	
	@FXML
	private Text bookstatus;
	
	@FXML
	private TextField BookID;
	
	@FXML
	private TextField memberIDinput;
	@FXML
	private Text membername;
	
	@FXML
	private Text membermobile;
	
	Boolean isReadyForSubmission = false;
	
	DatabaseHandler databasehandler;
	
	// Event Listener on Button.onAction  
	@FXML
	public void loadAddMember(ActionEvent event) {
		loadWindow("/addmember/MemberAdd.fxml", "Add New Member");
		
	}
	// Event Listener on Button.onAction
	@FXML
	public void loadAddBook(ActionEvent event) {
		loadWindow("/application/AddBook.fxml", "Add New Book");
	}
	// Event Listener on Button.onAction
	@FXML
	public void loadMemberTable(ActionEvent event) {
		loadWindow("/listmember/ListMember.fxml", "Member List");
	}
	// Event Listener on Button.onAction
	@FXML
	public void loadBookTable(ActionEvent event) {
		loadWindow("/listbook/ListBook.fxml", "Book List ");
	}
	
	@FXML
	public void loadSettings(ActionEvent event) {
		loadWindow("/settings/Settings.fxml", "Settings");
	}
	@FXML
	public void loadAbout(ActionEvent event) {
		loadWindow("/about/About.fxml", "About");
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		databasehandler = DatabaseHandler.getInstance();
		
	}
	
	void loadWindow(String loc,String title) {
		try {
			Parent parent = FXMLLoader.load(getClass().getResource(loc));
			Stage stage = new Stage(StageStyle.DECORATED);
			
			stage.setTitle(title);
			
			stage.setScene(new Scene(parent));
			LibraryAssistantUtil.setStageIcon(stage);
			
		
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@FXML
	private void loadBookInfo(ActionEvent event) {
	clearBookCache();
		String id = bookidinput.getText();//getting bookid from user 
		String qu = "select * from BOOK where id ='"+ id+"'";//query
		ResultSet rs = databasehandler.execQuery(qu);//executing query
		Boolean flag = false;
		try {
			while(rs.next()) {
				//select data from database.
				String bname = rs.getString("title");
				String bauthor = rs.getString("author");
				boolean bstatus = rs.getBoolean("isAvail");
				//setting value to text.
				bookname.setText(bname);
				bookauthor.setText(bauthor);
				String status = (bstatus)?"Available" : "Not Available";
				bookstatus.setText(status);
				
				flag=true;
				
			}
			if(!flag) {
				bookname.setText("No Such book Available");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FXML
	private void loadMemberInfo(ActionEvent event)
	{
		clearMemberCache();
		String id = memberIDinput.getText();//getting bookid from user 
		String qu = "select * from MEMBER where id ='"+ id+"'";//query
		ResultSet rs = databasehandler.execQuery(qu);//executing query
		Boolean flag = false;
		try {
			while(rs.next()) {
				//select data from database.
				String mname = rs.getString("name");
				String mauthor = rs.getString("mobile");
				
				//setting value to text.
				membername.setText(mname);
				membermobile.setText(mauthor);
				
				
				flag=true;
				
			}
			if(!flag) {
				membername.setText("No Such Member Available");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	//this method will clear all the data if book is not avaiable 
	void clearBookCache() {
		bookname.setText("");
		bookauthor.setText("");
		bookstatus.setText("");

	}
	//this method will clear all the data if member is not avaiable 
	void clearMemberCache() {
		membername.setText("");
		membermobile.setText("");
	}
	
	//issue operation
	@FXML
	private void loadIssueOperation(ActionEvent event) {
		String memberId = memberIDinput.getText();
		String bookID = bookidinput.getText();
		
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle("Confirm Issue");
		alert.setHeaderText(null);
		alert.setContentText("Are you sure you want to issue the book " + bookname.getText() + " \n to " + membername.getText() + "?");
		
		Optional<ButtonType> response = alert.showAndWait();
		if(response.get()==ButtonType.OK) {
			String  str = "INSERT INTO ISSUE(memberID,bookID) VALUES ("
					+ "'"+memberId +"',"
					+ "'"+bookID +"')";
			String str2 = "UPDATE BOOK SET isAvail = false where id= '"+bookID + "'";
			
			if(databasehandler.execAction(str) && databasehandler.execAction(str2)) {
				Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
				alert1.setTitle("Sucess Box");
				alert1.setHeaderText(null);
				alert1.setContentText("Book Issued Sucessfully");
				alert1.showAndWait();
			}
			else {
				Alert alert1 = new Alert(Alert.AlertType.ERROR);
				alert1.setTitle("Failed Box");
				alert1.setHeaderText(null);
				alert1.setContentText("Book Issued Failed,Please try again");
				alert1.showAndWait();
			}
		}else {
			Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
			alert1.setTitle("Cancelled");
			alert1.setHeaderText(null);
			alert1.setContentText("Book Issued Cancelled");
			alert1.showAndWait();
		}
	}
	
	@FXML
	private void loadBookInfo2(ActionEvent event) {
		
		ObservableList<String> issueData = FXCollections.observableArrayList();
		isReadyForSubmission = false;
		String id = BookID.getText();
		String qu = "select * from ISSUE where bookID = '"+id+ "'";
		ResultSet rs = databasehandler.execQuery(qu);
		
		try {
			while(rs.next()) {
				String mBookID = id;
				String mMemberID = rs.getString("MemberID");
				Timestamp  mIssueTime = rs.getTimestamp("issueTime");
				int mRenewCount = rs.getInt("renew_count");
				
				issueData.add("Issue date and time : "+mIssueTime);//this display time of issue
				issueData.add("Renew Count : "+mRenewCount);
				issueData.add("Book Information :");
				
				
				qu = "select * from BOOK where ID = '"+ mBookID+ "'";
				ResultSet r1 = databasehandler.execQuery(qu);
				while(r1.next()) {
					issueData.add("				Book Name : "+r1.getString("title"));
					issueData.add("				Book ID : "+r1.getString("id"));
					issueData.add("				Book Author : "+r1.getString("author"));
					issueData.add("				Book Publisher : "+r1.getString("publisher"));
				}
				
				issueData.add("Member Information :");
				qu = "select * from MEMBER where ID = '"+ mMemberID + "'";
				 r1 = databasehandler.execQuery(qu);
				while(r1.next()) {
					issueData.add("				Member Name :"+r1.getString("name"));
					issueData.add("				Member Mobile :"+r1.getString("mobile"));
					issueData.add("				Member Email :"+r1.getString("email"));
				}
				isReadyForSubmission = true;
			}	
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		issueDataList.getItems().setAll(issueData); 
		
	}
	
	//submission
	@FXML
	private void loadSubmission(ActionEvent event) {
		//if book is not selected then is if condition will run
		if(!isReadyForSubmission) {
			//if it is not ready for submission just return from function
			Alert alert1 = new Alert(Alert.AlertType.ERROR);
			alert1.setTitle("Error");
			alert1.setHeaderText(null);
			alert1.setContentText("Please select a book to submit");
			alert1.showAndWait();
			return;
		}
		
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle("Confirm Submission");
		alert.setHeaderText(null);
		alert.setContentText("Are you Sure you want to submit the book?");
		
		Optional<ButtonType> response = alert.showAndWait();
		if(response.get()==ButtonType.OK) {
		String id = BookID.getText();
		String ac1 = "delete from ISSUE where bookid ='"+id+"'";
		String ac2 = "update BOOK set isAvail = true where  id= '"+id+"'";
		
		if(databasehandler.execAction(ac1) && databasehandler.execAction(ac2)) {
			Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
			alert1.setTitle("Sucess");
			alert1.setHeaderText(null);
			alert1.setContentText("Book has been Submitted");
			alert1.showAndWait();
		}else {
			Alert alert1 = new Alert(Alert.AlertType.ERROR);
			alert1.setTitle("Error");
			alert1.setHeaderText(null);
			alert1.setContentText("Submission has Failed");
			alert1.showAndWait();
			}
		}else {
			Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
			alert1.setTitle("Cancelled");
			alert1.setHeaderText(null);
			alert1.setContentText("Book Submission Cancelled");
			alert1.showAndWait();
		}
	}
	
	@FXML
	private void loadRenew(ActionEvent event) {
		
		//if book is not selected then is if condition will run
				if(!isReadyForSubmission) {
					//if it is not ready for submission just return from function
					Alert alert1 = new Alert(Alert.AlertType.ERROR);
					alert1.setTitle("Error");
					alert1.setHeaderText(null);
					alert1.setContentText("Please select a book to renew");
					alert1.showAndWait();
					return;
				}
		
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle("Confirm Renew");
		alert.setHeaderText(null);
		alert.setContentText("Are you Sure you want to renew the book?");
		
		Optional<ButtonType> response = alert.showAndWait();
		if(response.get()==ButtonType.OK) {
			String ac = "update ISSUE SET issueTime = CURRENT_TIMESTAMP,renew_count=renew_count+1 where bookid = '"+ BookID.getText()+"'";
			
			if(databasehandler.execAction(ac))
			{
				Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
				alert1.setTitle("Sucess");
				alert1.setHeaderText(null);
				alert1.setContentText("Book has been Renewed");
				alert1.showAndWait();
			}else {
				Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
				alert1.setTitle("Cancelled");
				alert1.setHeaderText(null);
				alert1.setContentText("Book Renew Cancelled");
				alert1.showAndWait();
			}
		}else {
			Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
			alert1.setTitle("Cancelled");
			alert1.setHeaderText(null);
			alert1.setContentText("Book Renew Cancelled");
			alert1.showAndWait();
		}  
	}
	
	@FXML
	private void menuClose(ActionEvent event) {
		((Stage)rootpane.getScene().getWindow()).close();
	}
	@FXML
	private void menuAddBook(ActionEvent event) {
		loadWindow("/application/AddBook.fxml", "Add New Book");
		
	}
	@FXML
	private void menuAddMember(ActionEvent event) {
		loadWindow("/addmember/MemberAdd.fxml", "Add New Member");
	}
	
	@FXML
	private void menuViewBook(ActionEvent event) {
		loadWindow("/listbook/ListBook.fxml", "Book List ");
	}
	@FXML
	private void menuViewMember(ActionEvent event) {
		loadWindow("/listmember/ListMember.fxml", "Member List");
	}
	@FXML
	private void menuFullScreen(ActionEvent event) {
		Stage stage = ((Stage)rootpane.getScene().getWindow());
		stage.setFullScreen(!stage.isFullScreen());
	}
	@FXML
	private void menuAbout(ActionEvent event) {
		loadWindow("/about/About.fxml", "About");
	}
	
}
