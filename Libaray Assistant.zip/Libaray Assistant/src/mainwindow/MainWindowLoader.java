package mainwindow;

import database.DatabaseHandler;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import util.LibraryAssistantUtil;

public class MainWindowLoader extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		try {
			
			Parent root = FXMLLoader.load(getClass().getResource("/login/Login.fxml"));
			Scene scene = new Scene(root,400,400);
			//scene.getStylesheets().add(getClass().getResource("../login/NewFile.css").toExternalForm());
			
			primaryStage.setScene(scene);
			primaryStage.setTitle("Login");
			
			LibraryAssistantUtil.setStageIcon(primaryStage);
			primaryStage.show();
			
			//DatabaseHandler.getInstance();//main window will take time but this to load other fxml file quickly when we press add member etc
		
		//to remove the loading of main window
			new Thread( new Runnable() {
				public void run() {
					DatabaseHandler.getInstance();
				}
			}).start();
		
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	
	
}
