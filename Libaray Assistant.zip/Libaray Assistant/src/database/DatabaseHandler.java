package database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import listbook.ListBookController.Book;
import listmember.ListMemberController.Member;


public final class DatabaseHandler {

	
	
	private static DatabaseHandler handler = null;
	private static final String DB_URL = "jdbc:derby:database;create=true";//this will create database as folder and folder name will be database
	private static Connection conn = null;
	private static Statement stmt = null;
	
	private DatabaseHandler()
	{
		createConnection();
		setupBookTabel();
		setupMemberTabel();
		setupIssueTabel();
	}
	
	/*by calling this method we can get the object of databasehandler*/
	public static DatabaseHandler getInstance() {
		if(handler==null) {
			handler = new DatabaseHandler();
		}
		return handler;
	}
	
	void createConnection()
	{
		try {
			
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();//("is used to load the driver")
			conn = DriverManager.getConnection(DB_URL);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Application is Already Running");//if application is already running this will pop up
			System.exit(0);
			e.printStackTrace();
		}
	}
	
	void setupBookTabel(){
		String TABLE_NAME ="BOOK";
		try {
			stmt =conn.createStatement();
			DatabaseMetaData dbm = conn.getMetaData();
			ResultSet tables  = dbm .getTables(null,null,TABLE_NAME.toUpperCase(),null);
			if(tables.next())
			{
				System.out.println("Tables " + TABLE_NAME + "already exist. ready for go!");
				
			}else
			{
				stmt.execute("CREATE TABLE " + TABLE_NAME + "("
						+ "  id varchar(200) primary key,\n"
						+ "  title varchar(200),\n"
						+ "  author varchar(200),\n"
						+ "  publisher varchar(200),\n"
						+ "  isAvail boolean default true"
						+ ")");
						
			}
		} catch (Exception e) {
			System.err.println(e.getMessage()+ "..........setupdatabase");
		}
		
	}
	
	
	void setupMemberTabel(){
		String TABLE_NAME ="MEMBER";
		try {
			stmt =conn.createStatement();
			DatabaseMetaData dbm = conn.getMetaData();
			ResultSet tables  = dbm .getTables(null,null,TABLE_NAME.toUpperCase(),null);
			if(tables.next())
			{
				System.out.println("Tables " + TABLE_NAME + "already exist. ready for go!");
				
			}else
			{
				stmt.execute("CREATE TABLE " + TABLE_NAME + "("
						+ "  id varchar(200) primary key,\n"
						+ "  name varchar(200),\n"
						+ "  mobile varchar(20),\n"
						+ "  email varchar(100)\n"
					
						+ ")");
						
			}
		} catch (Exception e) {
			System.err.println(e.getMessage()+ "..........setupdatabase");
		}
		
	}
	
	void setupIssueTabel(){
		String TABLE_NAME ="ISSUE";
		try {
			stmt =conn.createStatement();
			DatabaseMetaData dbm = conn.getMetaData();
			ResultSet tables  = dbm .getTables(null,null,TABLE_NAME.toUpperCase(),null);
			if(tables.next())
			{
				System.out.println("Tables " + TABLE_NAME + "already exist. ready for go!");
				
			}else
			{
				stmt.execute("CREATE TABLE " + TABLE_NAME + "("
						+ "  bookID varchar(200) primary key,\n"
						+ "  memberID varchar(200),\n"
						+ "  issueTime timestamp default CURRENT_TIMESTAMP,\n"
						+ "  renew_count integer default 0,\n"
						+ "  FOREIGN KEY (bookID) REFERENCES BOOK(id),\n"
						+ "  FOREIGN KEY (memberID) REFERENCES MEMBER(id)\n"
					
						+ ")");
						
			}
		} catch (Exception e) {
			System.err.println(e.getMessage()+ "..........setupdatabase");
		}
		
	}
	//to execute query like select stmt
	
	public ResultSet execQuery(String query) {
		
		
		ResultSet result;
		try {
			stmt = conn.createStatement();
			result = stmt.executeQuery(query);
			
		} catch (Exception e) {
			System.out.println("Exception at execQuery: Handler " + e.getLocalizedMessage());
			return null;
		}finally {
			
		}
		return result;
		
	}
	
	//to insert and create data this method returns that whether the action is complete or not
	public boolean execAction(String Qu) {
		try {
			stmt = conn.createStatement();
			stmt.execute(Qu);
			return true;
			
		} catch (Exception e) {
			//display error msg on dialog box
			System.out.println("Exception at execAction "+e.getLocalizedMessage());
			return false;
		}finally {
			
		}
	}
	
	
	public Boolean deleteBook(Book book) {
		String deleteStatement = "delete from BOOK where ID = ?";
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(deleteStatement);
			stmt.setString(1,book.getId());
			int res = stmt.executeUpdate();
			if(res == 1) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return false;
		
		
	}
	
	public Boolean deleteMember(Member member) {
		String deleteStatement = "delete from MEMBER where ID = ?";
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(deleteStatement);
			stmt.setString(1,member.getId());
			int res = stmt.executeUpdate();
			if(res == 1) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return false;
		
		
	}
	
	
	//currently database itself is checking that book is issued or not bcz we set bookid as forgein key in issue table
	//when we try to delete issued book it will ask confirmation to delete. which is not appropriate
	//to fix this we are writting this method which will stop user to ask for confirmation or go to that step
	
	public boolean isBookAlreadyIssued(Book book) {
		String checkstmt = "select count(*) from ISSUE where bookID= ?";
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(checkstmt);
			stmt.setString(1,book.getId());
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				int count = rs.getInt(1);
				if(count>0) {
					return true;
				}else
				{
					return false;
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return false;
		
	}
	public boolean isMemberHaveBook(Member member) {
		String checkstmt = "select count(*) from ISSUE where memberID= ?";
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(checkstmt);
			stmt.setString(1,member.getId());
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				int count = rs.getInt(1);
				if(count>0) {
					return true;
				}else
				{
					return false;
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return false;
		
	}
	
	public boolean updateBook(Book book) {
		try {
			String update = "update BOOK set TITLE=? , AUTHOR=?, PUBLISHER=? WHERE ID=? ";
			PreparedStatement stmt = conn.prepareStatement(update);
			
			stmt.setString(1,book.getTitle());
			stmt.setString(2,book.getAuthor());
			stmt.setString(3, book.getPublisher());
			stmt.setString(4, book.getId());
			int res = stmt.executeUpdate();
			if(res == 1) {
				return true;
				
			}else {
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean updateMember(Member member) {
		try {
			String update = "update MEMBER set NAME=? , Email=?, MOBILE=? WHERE ID=? ";
			PreparedStatement stmt = conn.prepareStatement(update);
			
			stmt.setString(1,member.getName());
			stmt.setString(2,member.getEmail());
			stmt.setString(3,member.getMobile());
			stmt.setString(4,member.getId());
			int res = stmt.executeUpdate();
			if(res == 1) {
				return true;
				
			}else {
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;  
	}
	
}
