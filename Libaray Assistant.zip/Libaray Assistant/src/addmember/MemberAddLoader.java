package addmember;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MemberAddLoader extends Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/addmember/MemberAdd.fxml"));
			Scene scene = new Scene(root,400,400);
			primaryStage.initModality(Modality.WINDOW_MODAL);
			primaryStage.initOwner(primaryStage);
			scene.getStylesheets().add(getClass().getResource("memberAdd.css").toExternalForm());
			primaryStage.setScene(scene);
			
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
