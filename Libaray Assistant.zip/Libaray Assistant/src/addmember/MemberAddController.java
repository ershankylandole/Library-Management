package addmember;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import listbook.ListBookController;
import listmember.ListMemberController;
import listmember.ListMemberController.Member;
import listmember.MemberListLoader;

import java.net.URL;
import java.util.ResourceBundle;

import alert.AlertMaker;
import database.DatabaseHandler;
import javafx.event.ActionEvent;

public class MemberAddController implements Initializable {
	
	DatabaseHandler handler;
	
	@FXML
	private TextField name;
	@FXML
	private TextField id;
	@FXML
	private TextField mobile;
	@FXML
	private TextField email;
	@FXML
	private Button savebutton;
	@FXML
	private Button cancelbutton;
	@FXML
	private AnchorPane rootpane;

	private Boolean isInEditMode = false;
	
	// Event Listener on Button[#savebutton].onAction
	@FXML
	public void addmember(ActionEvent event) {
		String memberName = name.getText();
		String memberId = id.getText();
		String memberMobile = mobile.getText();
		String memberEmail = email.getText();
		
		Boolean flag = memberName.isEmpty() || memberId.isEmpty() || memberMobile.isEmpty() || memberEmail.isEmpty();
		if(flag){
			Alert al = new Alert(Alert.AlertType.ERROR);
			al.setHeaderText(null);
			al.setContentText("Plese enter in all Fields");
			al.showAndWait();
			return;
		}
		
		if(isInEditMode) {
			handleEditOperation();
			return;
		}
		
		 String st = "insert into MEMBER values("+
		"'"+ memberId +"',"+
		"'"+ memberName +"',"+
		"'"+ memberMobile +"',"+
		"'"+ memberEmail +"'"+
		")";
		 System.out.println(st);
		 if(handler.execAction(st)) {
			 Alert al = new Alert(Alert.AlertType.INFORMATION);
				al.setHeaderText(null);
				al.setContentText("Inserted Sucessfully!");
				al.showAndWait();
				
		 }else { 
			 Alert al = new Alert(Alert.AlertType.ERROR);
				al.setHeaderText(null);
				al.setContentText("Error! Please Try Again");
				al.showAndWait();
				return;
		 }
		  
		
		
	}
private void handleEditOperation() {
		
		ListMemberController.Member member = new ListMemberController.Member(name.getText(), id.getText(), mobile.getText(), email.getText());
		
		if(DatabaseHandler.getInstance().updateMember(member)) {
			AlertMaker.showSimpleAlert("Success", "Member Updated");
			
		}else {
			AlertMaker.showErrorMessage("Failed","Cant update Member");
		}
	}

	// Event Listener on Button[#cancelbutton].onAction
	@FXML
	public void cancel(ActionEvent event) {
		Stage stage = (Stage) rootpane.getScene().getWindow();
		stage.close();
		
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		handler = DatabaseHandler.getInstance();
		
	}
	
public void inFlateUI(ListMemberController.Member member) {
		
		name.setText(member.getName());
		id.setText(member.getId());
		mobile.setText(member.getMobile());
		email.setText(member.getEmail());
		isInEditMode = true;
		id.setEditable(false);
		
	}
}
