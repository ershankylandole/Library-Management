package listbook;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import alert.AlertMaker;
import application.AddBookController;
import database.DatabaseHandler;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;

public class ListBookController implements Initializable {
	@FXML
	private AnchorPane rootpane;
	@FXML
	private TableView<Book> tableview;
	@FXML
	private TableColumn<Book,String> titlecol;
	@FXML
	private TableColumn<Book,String> idcol;
	@FXML
	private TableColumn<Book,String> authorcol;
	@FXML
	private TableColumn<Book,String> publishercol;
	@FXML
	private TableColumn<Book,Boolean> availabilitycol;
	
	ObservableList<Book> list  = FXCollections.observableArrayList();
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		initCol();
		
		
		loadData();
	}
	
	//selecting all data
	private void loadData() {
		
		list.clear();//this will clear the list first and following code will run in order to stop making copies of data
		DatabaseHandler handler = DatabaseHandler.getInstance();
		String qu = "select * from BOOK";
		ResultSet rs = handler.execQuery(qu);
		
		try {
			while(rs.next())
			{
				String title = rs.getString("title");
				String author = rs.getString("author");
				String id = rs.getString("id");
				String publisher = rs.getString("publisher");
				Boolean avail = rs.getBoolean("isAvail");
				
				list.add(new Book(title, id, author, publisher, avail));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(AddBookController.class.getName()).log(Level.SEVERE,null, e);
		}
		
		tableview.setItems(list);//this will refresh the list once we perform deletion action
		
		
	}
	
	//this method is associating all the values with table
	private void initCol() {
		titlecol.setCellValueFactory(new PropertyValueFactory<>("title"));//this will associate the title col in the table with the title in the book
		idcol.setCellValueFactory(new PropertyValueFactory<>("id"));
		authorcol.setCellValueFactory(new PropertyValueFactory<>("author"));
		publishercol.setCellValueFactory(new PropertyValueFactory<>("publisher"));
		availabilitycol.setCellValueFactory(new PropertyValueFactory<>("availability"));
	}

	public static class Book{
		private  final SimpleStringProperty title;
		private  final SimpleStringProperty id;;
		private  final SimpleStringProperty author;
		private  final SimpleStringProperty publisher;
		private  final SimpleBooleanProperty availability;
		
		public Book(String title, String id,String author,String pub, Boolean avail){
			this.title = new SimpleStringProperty(title);
			this.id = new SimpleStringProperty(id);
			this.author = new SimpleStringProperty(author);
			this.publisher = new SimpleStringProperty(pub);
			this.availability = new SimpleBooleanProperty(avail);
		}

		public String getTitle() {
			return title.get();
		}

		public String getId() {
			return id.get();
		}

		public String getAuthor() {
			return author.get();
		}

		public String getPublisher() {
			return publisher.get();
		}

		public Boolean getAvailability() {
			return availability.get();
		}
		
	}
	//this method is deleting single book try to delete multiple books
	@FXML
	private void bookDelete(ActionEvent event) {
		//fetch the select row
		Book selectedfordeletion = tableview.getSelectionModel().getSelectedItem();
		
		
		if(selectedfordeletion == null) {
			AlertMaker.showErrorMessage("No Book Selected", "Please select a book for deletion");
			return; 
		}
		
		
		//if book is already issued this will display
		Boolean issued = DatabaseHandler.getInstance().isBookAlreadyIssued(selectedfordeletion);
		if(issued == true)
		{
			AlertMaker.showSimpleAlert("Falied","Can not be deleted, book is already issued");
			return;
		}
		
		
		
		
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle("Delete Confirmation");
		alert.setContentText("Are you sure you want to delete book? "+selectedfordeletion.getTitle());
		//reading the response of user
		
		Optional<ButtonType> answer = alert.showAndWait();
		if(answer.get() == ButtonType.OK) {
			Boolean res = DatabaseHandler.getInstance().deleteBook(selectedfordeletion);
			if(res)
			{
				AlertMaker.showSimpleAlert("Book Deleted", selectedfordeletion.getTitle()+ " was deleted successfully");
				list.remove(selectedfordeletion);
			}
			else {
				AlertMaker.showSimpleAlert("Failed", selectedfordeletion.getTitle()+ " Could not be deleted, It is Issued");
			}
		}else {
			AlertMaker.showSimpleAlert("Deletion Canceled","Deletion Canceled");
		}
	}
	
	@FXML
	private void bookEdit(ActionEvent event) {
		//fetch the select row
		Book selectedforedit = tableview.getSelectionModel().getSelectedItem();
		
		
		if(selectedforedit == null) {
			AlertMaker.showErrorMessage("No Book Selected", "Please select a book for Edit");
			return; 
		}
		
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/AddBook.fxml"));
			Parent parent = loader.load();
			
			AddBookController controller = loader.getController();//creating object of  addbookcontroller so that we can pass data to add book controller for editing option
			 controller.inFlateUI(selectedforedit);
			 
			 
			Stage stage = new Stage(StageStyle.DECORATED);
			stage.setTitle("Edit book");
			stage.setScene(new Scene(parent));
			stage.show();
			
			//this will automatically refersh the list
			stage.setOnCloseRequest((e)->{
				bookReferesh(new ActionEvent());
			});
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//to referesh the book list
	
	@FXML
	private void bookReferesh(ActionEvent event) {
		loadData();
	}
	

}
