package login;

import javafx.fxml.FXML;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import settings.Preferences;
import util.LibraryAssistantUtil;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;

public class LoginController implements Initializable {
	@FXML
	private Label title;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	Preferences preferences;
	@FXML
	public void login(ActionEvent event) {
		
		
		String uname = username.getText();
		String pass = password.getText();
		
		if(uname.equals(preferences.getUsername()) && pass.equals(preferences.getPassword())) {
				closeStage();
				loadMain();
		}else {
			title.setText("Invalid Credentials!! Please Try Again");
			title.setStyle("-fx-text-fill:red");
		}

	}
	
	@FXML
	public void cancel(ActionEvent event) {
		System.exit(0);
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		preferences = Preferences.getpreferences();//this will read the data from config.txt
	}
	
	void loadMain() {
		try {
			Parent parent = FXMLLoader.load(getClass().getResource("/mainwindow/MainWindow.fxml"));
			Stage stage = new Stage(StageStyle.DECORATED);
			stage.setTitle("Library Manager");
			stage.setScene(new Scene(parent));
			LibraryAssistantUtil.setStageIcon(stage);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void closeStage() {
		 
		((Stage)username.getScene().getWindow()).close();
		
	}
}
