package alert;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class AlertMaker {


	public static void showSimpleAlert(String title,String content) {
		
		Alert al = new Alert(AlertType.INFORMATION);
		al.setTitle(title);
		al.setHeaderText(null);
		al.setContentText(content);
		al.showAndWait();
		
	}
	

	public static void showErrorMessage(String title,String content) {
		
		Alert al = new Alert(AlertType.ERROR);
		al.setTitle("Error");
		al.setHeaderText(title);
		al.setContentText(content);
		al.showAndWait();
		
	}
}
